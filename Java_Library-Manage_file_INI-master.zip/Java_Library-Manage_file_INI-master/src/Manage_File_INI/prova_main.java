/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_File_INI;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class prova_main
 * Questa classe si occupa di provare il funzionamento dei metodi implementati nelle altre classi
 * 
 * @author salva
 */
public class prova_main {

    /**
     *
     * @param args ??? TO DO ???
     * @throws FileNotFoundException Qualora il file da leggere non venga trovato
     * @throws SectionNotExistException Qualora la sezione non esista
     * @throws ParamAlreadyExistException Qualora il parametro esista gi&agrave
     * @throws IOException   ??? TO DO ???
     * @throws SectionAlreadyExistException Qualora la sezione che vogliamo creare esista gi&agrave
     */
    public static void main(String [] args) throws FileNotFoundException, SectionNotExistException, ParamAlreadyExistException, IOException, SectionAlreadyExistException{
        Config c=new Config();
        IniReader b=new IniReader(c);
        b.Reader();
        IniWriter a=new IniWriter();
        try{
            c.addSection("Section4");
        }catch(SectionAlreadyExistException e){}
        try{
            c.addParam("Section4","Param1", "0");
        }catch(ParamAlreadyExistException e){}
        try{
            c.addParam("Section4","Param2", "0");
        }catch(ParamAlreadyExistException e){}
        try{
            c.addParam("Section4","Param3", "0");
        }catch(ParamAlreadyExistException e){}
        try{
            c.addParam("Section4","Param4", "0");
        }catch(ParamAlreadyExistException e){}
        try {
            c.addSection("Section3");
        } catch (SectionAlreadyExistException e) {}
        a.write(c);
    }
}