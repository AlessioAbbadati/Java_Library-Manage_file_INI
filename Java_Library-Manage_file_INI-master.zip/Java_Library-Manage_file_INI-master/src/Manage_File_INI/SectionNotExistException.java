/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_File_INI;

/**
 * Class SectionNotExistException
 * Questa classe si occupa di gestire l'eccezione nel caso in cui la sezione non esista
 * 
 * @author Abbadati Alessio, Dinaro Salvatore & Multani Prabhdeep
 */
public class SectionNotExistException extends Exception{

    /**
     *
     * @param name Il nome della sezione che non esiste
     */
    public SectionNotExistException(String name){
        super("La sezione '"+name+"' non esiste.");
    }
}
