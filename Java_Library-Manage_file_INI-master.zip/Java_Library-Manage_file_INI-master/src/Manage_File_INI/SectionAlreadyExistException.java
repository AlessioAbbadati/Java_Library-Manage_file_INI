
package Manage_File_INI;

/**
 * Class SectionAlreadyExistException
 * Questa classe si occupa di gestire l'eccezione nel caso in cui la sezione esista gi&agrave
 * 
 * @author Abbadati Alessio, Dinaro Salvatore & Multani Prabhdeep
 */
public class SectionAlreadyExistException extends Exception{

    /**
     *
     * @param name Il nome della sezione che esiste gi&agrave
     */
    public SectionAlreadyExistException(String name){
        super("La sezione '"+name+"' è gia esistente.");
    }
}