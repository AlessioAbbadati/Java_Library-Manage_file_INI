/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_File_INI;

import Manage_File_INI.ParamNotExistException;
import java.util.List;
import java.util.ArrayList;

/**
 * Class Section
 * Questa classe si occupa di gestire il contenuto delle sezioni, ovvero i parametri con i loro valori
 * 
 * @author Abbadati Alessio, Dinaro Salvatore & Multani Prabhdeep
 */
public class Section {

    /**
     * Dichiariamo che lavoriamo con oggetti della classe String
     */
    protected List<String> parameter;

    private String name;

    /**
     *
     * @param name Il nome della sezione nella quale vogliamo lavorare sui parametri
     */
    public Section(String name) {
        parameter = new ArrayList();
        this.name = name;
    }

    /**
     *
     * @return Ritorna il nome della sezione attuale
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name Il nome del parametro che vogliamo aggiungere
     * @param value Il valore che vogliamo attribuire al parametro
     * @throws ParamAlreadyExistException Qualora il parametro esista gi&agrave
     */
    public void addParam(String name, String value) throws ParamAlreadyExistException {
        for (int i = 0; i < parameter.size(); i++) {
            String param = parameter.get(i);
            for (int j = 0; j < param.length(); j++) {
                if (param.charAt(j) == '=') {
                    if (param.substring(0, j).equals(name)) {
                        throw new ParamAlreadyExistException(name);
                    }
                }
            }
        }
        parameter.add(name + "=" + value);
    }

    /**
     * 
     * @return   ??? TO DO ???
     */
    public int getSize() {
        return parameter.size();
    }

    /**
     * 
     * @param name Il nome del parametro che vogliamo rimuovere
     */
    public void removeParam(String name) {
        for (int i = 0; i < parameter.size(); i++) {
            String param = parameter.get(i);
            for (int j = 0; j < param.length(); j++) {
                if (param.charAt(j) == '=') {
                    if (param.substring(0, j).equals(name)) {
                        parameter.remove(i);
                        break;
                    }
                }
            }
            break;
        }
    }

    /**
     *
     * @param name Il nome del parametro di cui vogliamo ottenere il valore
     * @return
     */
    public String getParam(String name) {
        for (int i = 0; i < parameter.size(); i++) {
            for (int j = 0; j < parameter.get(i).length(); j++) {
                if (parameter.get(i).charAt(j) == '=') {
                    if (parameter.get(i).substring(0, j).equals(name)) {
                        return parameter.get(i).substring(j + 1);
                    }
                }
            }
        }
        return null;
    }
}
