package Manage_File_INI;

import Manage_File_INI.SectionAlreadyExistException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class Config
 * Questa classe si occupa di gestire le sezioni
 * 
 * @author Abbadati Alessio, Dinaro Salvatore & Multani Prabhdeep
 */
public class Config{
    
    /**
     * Dichiariamo che lavoriamo con oggetti della classe Section
     */
    protected List<Section> Sections;
   
    public Config(){
        /**
         * Creiamo la lista Sections
         */
        Sections=new ArrayList<Section>();
    }
    
    /**
     * @method addSection Il metodo che ci permette di aggiungere una sezione alla lista
     * @param name Il nome della sezione da aggiungere alla lista
     * @throws SectionAlreadyExistException Qualora la sezione che vogliamo creare esista gi&agrave
     */
    public void addSection(String name) throws SectionAlreadyExistException{
        for(int i=0; i<Sections.size(); i++){
            if(Sections.get(i).getName().equals(name)){
                throw new SectionAlreadyExistException(name);
            }
        }
        Section s=new Section(name);
        Sections.add(s);
    }
    
    /**
     *
     * @param name Il nome della sezione che vogliamo rimuovere dalla lista
     */
    public void removeSection(String name){
        for(int i=0; i<Sections.size(); i++){
            if(Sections.get(i).getName().equals(name)){
                Sections.remove(i);
                break;
            }
        }
    }
    
    /**
     *
     * @param name Il nome della sezione di cui vogliamo verificare l'esistenza
     * @return <code>true</code> se la sezione esiste, <code>false</code> altrimenti
     */
    public boolean ExistSection(String name){
        for(int i=0; i<Sections.size(); i++){
            if(Sections.get(i).getName().equals(name)){
                return true;
            }
        }
        return false;
    }
    
    /**
     *
     * @param section_name Il nome della sezione alla quale vogliamo aggiungere un parametro
     * @param name Il nome che vogliamo dare al parametro
     * @param value Il valore che vogliamo attribuire al parametro
     * @throws SectionNotExistException Qualora la sezione non esista
     * @throws ParamAlreadyExistException Qualora il parametro esista gi&agrave
     */
    public void addParam(String section_name, String name, String value) throws SectionNotExistException, ParamAlreadyExistException{
        int i;
        for(i=0; i<Sections.size(); i++){
            if(Sections.get(i).getName().equals(section_name)){
                for(int j=0; j<Sections.get(i).parameter.size(); j++){
                    if(Sections.get(i).parameter.get(j).equals(name+"="+value)){
                        throw new ParamAlreadyExistException(name);
                    }
                }
                Sections.get(i).addParam(name, value);
                break;
            }
        }
        if(i==Sections.size()) throw new SectionNotExistException(section_name);
    }
    
    /**
     *
     * @param section_name Il nome della sezione alla quale vogliamo aggiungere un parametro
     * @param name Il nome del parametro che vogliamo eliminare
     * @throws SectionNotExistException Qualora la sezione non esista
     */
    public void removeParam(String section_name, String name) throws SectionNotExistException{
        int i;
        for(i=0; i<Sections.size(); i++){
            if(Sections.get(i).getName().equals(section_name)){
                Sections.get(i).removeParam(name);
                break;
            }
        }
        if(i==Sections.size()) throw new SectionNotExistException(section_name);
    }
    
    /**
     *
     * @param section_name Il nome della sezione alla quale vogliamo aggiungere un parametro
     * @param name Il nome del parametro di cui vogliamo avere il valore
     * @return <code>null</code> la sezione non esiste, altrimenti viene ritornato il valore del parametro
     * @throws SectionNotExistException Qualora la sezione non esista
     */
    public String getParam(String section_name, String name) throws SectionNotExistException{
        int i;
        for(i=0; i<Sections.size(); i++){
            if(Sections.get(i).getName().equals(section_name)){
                return Sections.get(i).getParam(name);
            }
        }
        if(i==Sections.size()) throw new SectionNotExistException(section_name);
        return null;
    }
}
