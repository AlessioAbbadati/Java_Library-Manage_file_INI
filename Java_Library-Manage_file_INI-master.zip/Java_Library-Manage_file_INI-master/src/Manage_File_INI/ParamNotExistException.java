/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_File_INI;

/**
 * Class ParamNotExistException
 * Questa classe si occupa di gestire l'eccezione nel caso in cui il parametro non esista
 * 
 * @author Abbadati Alessio, Dinaro Salvatore & Multani Prabhdeep
 */
public class ParamNotExistException extends Exception{

    /**
     *
     * @param name Il nome del parametro che non esiste
     */
    public ParamNotExistException(String name){
        super("Il parametro '"+name+"' non esiste.");
    }
}
