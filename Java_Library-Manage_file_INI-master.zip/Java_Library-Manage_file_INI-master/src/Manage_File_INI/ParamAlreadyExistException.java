/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage_File_INI;

/**
 * Class ParamAlreadyExistException
 * Questa classe si occupa di gestire l'eccezione nel caso in cui il parametro esista gi&agrave
 * 
 * @author Abbadati Alessio, Dinaro Salvatore & Multani Prabhdeep
 */
public class ParamAlreadyExistException extends Exception{

    /**
     *
     * @param name Il nome del parametro che esiste gi&agrave
     */
    public ParamAlreadyExistException(String name){
        super("Il parametro '"+name+"' è gia esistente.");
    }
}
