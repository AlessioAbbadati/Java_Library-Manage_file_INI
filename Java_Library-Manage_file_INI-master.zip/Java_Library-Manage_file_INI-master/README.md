# Java_Library-Manage_file_INI
This project read a file .ini and it can changed the configuration 
